fx_version 'cerulean'

game 'gta5'

author 'poseidondev'
description 'Give All Item Scipt'
version '1.0.0'

lua54 'yes'

server_script 'giveall.lua'