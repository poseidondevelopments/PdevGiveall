-- Ensure QBCore is loaded
local QBCore = exports['qb-core']:GetCoreObject()

-- Register the "giveall" command
QBCore.Commands.Add("giveall", "Give an item, weapon, or money to all players (Admin Only)", {
    {name = "type", help = "Type of item to give (item/weapon/money)"},
    {name = "name", help = "Name of the item/weapon (e.g., bread, WEAPON_PISTOL)"},
    {name = "amount", help = "Amount to give (e.g., 1, 1000)"}
}, true, function(source, args)
    -- Validate input arguments
    local itemType = args[1] -- Type: item, weapon, or money
    local itemName = args[2] -- Name of the item/weapon
    local amount = tonumber(args[3]) -- Amount to give

    if not itemType or not itemName or not amount then
        TriggerClientEvent('QBCore:Notify', source, "Invalid arguments. Usage: /giveall <type> <name> <amount>", "error")
        return
    end

    -- Get all online players
    local players = QBCore.Functions.GetPlayers()

    -- Iterate through all players and give the specified item
    for _, playerId in ipairs(players) do
        local Player = QBCore.Functions.GetPlayer(playerId)

        if Player then
            if itemType == "item" then
                -- Give an item
                if Player.Functions.AddItem(itemName, amount) then
                    TriggerClientEvent('inventory:client:ItemBox', playerId, QBCore.Shared.Items[itemName], "add")
                else
                    print("Failed to give item to player ID: " .. playerId)
                end
            elseif itemType == "weapon" then
                -- Give a weapon
                Player.Functions.AddItem(itemName, 1) -- Add weapon as an item
                TriggerClientEvent('inventory:client:ItemBox', playerId, QBCore.Shared.Items[itemName], "add")
            elseif itemType == "money" then
                -- Give money
                Player.Functions.AddMoney("cash", amount)
            else
                TriggerClientEvent('QBCore:Notify', source, "Invalid type. Use 'item', 'weapon', or 'money'.", "error")
                return
            end
        end
    end

    -- Notify the admin that the command was executed
    TriggerClientEvent('QBCore:Notify', source, "Successfully gave " .. amount .. " " .. itemName .. " to all players.", "success")
end, "admin") -- Restrict to admin only